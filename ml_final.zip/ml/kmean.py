import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

from sklearn.datasets import fetch_openml
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.cluster import KMeans

# Load the MNIST dataset
mnist = fetch_openml("mnist_784", version=1)
X = mnist.data.to_numpy()
y = mnist.target.to_numpy()

# Display the first 25 images
plt.figure(figsize=(10,10))
for i in range(25):
    plt.subplot(5,5,i+1)
    plt.imshow(X[i].reshape(28,28), cmap="gray")
    plt.title(f"Label: {y[i]}")
    plt.axis("off")
plt.show()

# Convert y to integer
y = y.astype(int)

# Normalize the data
scaler = MinMaxScaler()
X = scaler.fit_transform(X)

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train KMeans clustering model
model = KMeans(n_clusters=10, random_state=42)
model.fit(X_train)

# Get the cluster centers
centers = model.cluster_centers_

# Display the cluster centers as images
plt.figure(figsize=(10, 5))
for i in range(10):
    plt.subplot(2, 5, i + 1)
    plt.imshow(centers[i].reshape(28,28), cmap='gray')
    plt.title(f"Cluster {i}")
    plt.axis('off')
plt.show()

# Predict clusters for test data
from sklearn.metrics import accuracy_score
from scipy.stats import mode

test_preds = model.predict(X_test)

# Map each cluster to the most common actual digit
labels = np.zeros(10)

for i in range(10):
    mask = (test_preds == i)
    labels[i] = mode(y_test[mask])[0]

# Map the cluster predictions to the true digit labels
mapped_preds = labels[test_preds.astype(int)]

# Calculate accuracy
accuracy = accuracy_score(y_test, mapped_preds)
print(f"Clustering Accuracy: {accuracy:.4f}")
