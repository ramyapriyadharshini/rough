# import pandas as pd
# import numpy as np
# import matplotlib.pyplot as plt

# # Load the dataset
# df = pd.read_csv("abalone.csv")

# # Display the first few rows of the dataset
# print(df.head())

# # Define dependent variable (y)
# y = df['Rings'] + 1.5  # Age = Rings + 1.5

# # ==============================================
# # 1. Simple Linear Regression (One Feature)
# # ==============================================

# def simple_linear_regression(X, y):
#     """
#     Perform simple linear regression with one feature.
    
#     Parameters:
#     - X: Independent variable (1D array).
#     - y: Dependent variable (1D array).
    
#     Returns:
#     - w0: Intercept.
#     - w1: Slope.
#     - y_pred: Predicted values.
#     """
#     # Step 1: Compute mean
#     X_mean = X.mean()
#     y_mean = y.mean()

#     # Step 2: Compute slope (w1)
#     numerator = sum((X - X_mean) * (y - y_mean))
#     denominator = sum((X - X_mean) ** 2)
#     w1 = numerator / denominator

#     # Step 3: Compute intercept (w0)
#     w0 = y_mean - (w1 * X_mean)

#     # Step 4: Predict values
#     y_pred = w0 + (w1 * X)

#     return w0, w1, y_pred

# # Example: Simple Linear Regression with 'Length' as the feature
# X_simple = df['Length']
# w0, w1, y_pred_simple = simple_linear_regression(X_simple, y)

# # Calculate Mean Squared Error (MSE)
# mse_simple = sum((y - y_pred_simple) ** 2) / len(y)
# print(f"Simple Linear Regression MSE: {mse_simple:.2f}")

# # Visualize Simple Linear Regression
# plt.figure(figsize=(10, 6))
# plt.scatter(X_simple, y, color='blue', label='Data Points')
# plt.plot(X_simple, y_pred_simple, color='red', label='Regression Line')
# plt.xlabel('Length')
# plt.ylabel('Age (Rings + 1.5)')
# plt.title('Simple Linear Regression: Length vs Age')
# plt.legend()
# plt.grid(True)
# plt.show()

# # ==============================================
# # 2. Multiple Linear Regression (Multiple Features)
# # ==============================================

# def multiple_linear_regression(X, y):
#     """
#     Perform multiple linear regression with multiple features.
    
#     Parameters:
#     - X: Independent variables (2D array).
#     - y: Dependent variable (1D array).
    
#     Returns:
#     - coefficients: Coefficients (w1, w2, ..., wn).
#     - intercept: Intercept (w0).
#     - y_pred: Predicted values.
#     """
#     # Add a column of 1's to X for the intercept term
#     X = np.c_[np.ones(X.shape[0]), X]

#     # Step 1: Compute coefficients using the normal equation
#     coefficients = np.linalg.inv(X.T @ X) @ X.T @ y

#     # Separate intercept and coefficients
#     intercept = coefficients[0]
#     coefficients = coefficients[1:]

#     # Step 2: Predict values
#     y_pred = X @ np.r_[intercept, coefficients]

#     return coefficients, intercept, y_pred

# # Example: Multiple Linear Regression with 'Length', 'Diameter', 'Height', 'Whole weight'
# X_multiple = df[['Length', 'Diameter', 'Height', 'Whole weight']].values
# coefficients, intercept, y_pred_multiple = multiple_linear_regression(X_multiple, y)

# # Calculate Mean Squared Error (MSE)
# mse_multiple = sum((y - y_pred_multiple) ** 2) / len(y)
# print(f"Multiple Linear Regression MSE: {mse_multiple:.2f}")

# # Visualize Multiple Linear Regression (for one feature, e.g., Length)
# plt.figure(figsize=(10, 6))
# plt.scatter(X_multiple[:, 0], y, color='blue', label='Data Points')
# plt.scatter(X_multiple[:, 0], y_pred_multiple, color='red', label='Predicted Values')
# plt.xlabel('Length')
# plt.ylabel('Age (Rings + 1.5)')
# plt.title('Multiple Linear Regression: Length vs Age')
# plt.legend()
# plt.grid(True)
# plt.show()

# ==============================================
# 3. Logistic Regression (Binary Classification)
# ==============================================

# # 
# import pandas as pd
# import numpy as np
# import matplotlib.pyplot as plt

# # Load the dataset
# df = pd.read_csv("abalone.csv")

# # Display the first few rows of the dataset
# print(df.head())

# # Define dependent variable (y)
# # Convert target to binary (1 if age >= 10, else 0)
# y = (df['Rings'] + 1.5 >= 10).astype(int)  # Age = Rings + 1.5

# # ==============================================
# # 1. Logistic Regression (One Feature)
# # ==============================================

# def sigmoid(z):
#     """
#     Sigmoid function.
    
#     Parameters:
#     - z: Input value.
    
#     Returns:
#     - Sigmoid of z.
#     """
#     return 1 / (1 + np.exp(-z))

# def logistic_regression(X, y, learning_rate=0.01, epochs=1000):
#     """
#     Perform logistic regression with one feature.
    
#     Parameters:
#     - X: Independent variable (1D array).
#     - y: Dependent variable (1D array, binary).
#     - learning_rate: Learning rate for gradient descent.
#     - epochs: Number of iterations.
    
#     Returns:
#     - w0: Intercept.
#     - w1: Slope.
#     - y_pred: Predicted probabilities.
#     - mse_history: List of MSE values over epochs.
#     """
#     # Normalize the feature
#     X_mean = X.mean()
#     X_std = X.std()
#     X_normalized = (X - X_mean) / X_std

#     # Initialize parameters
#     w0 = 0
#     w1 = 0
#     n = len(X)
#     mse_history = []

#     # Gradient Descent
#     for _ in range(epochs):
#         # Compute linear combination
#         z = w0 + (w1 * X_normalized)

#         # Predict probabilities
#         y_pred = sigmoid(z)

#         # Compute gradients
#         dw0 = (-1/n) * sum(y - y_pred)
#         dw1 = (-1/n) * sum(X_normalized * (y - y_pred))

#         # Update parameters
#         w0 -= learning_rate * dw0
#         w1 -= learning_rate * dw1

#         # Compute log loss (binary cross-entropy)
#         log_loss = (-1/n) * sum(y * np.log(y_pred) + (1 - y) * np.log(1 - y_pred))
#         mse_history.append(log_loss)

#     # Final predictions
#     y_pred = sigmoid(w0 + (w1 * X_normalized))

#     return w0, w1, y_pred, mse_history

# # Example: Logistic Regression with 'Length' as the feature
# X_logistic = df['Length']
# w0, w1, y_pred_logistic, mse_history_logistic = logistic_regression(X_logistic, y, learning_rate=0.01, epochs=1000)

# # Calculate Accuracy
# y_pred_class = (y_pred_logistic >= 0.5).astype(int)
# accuracy = (y == y_pred_class).mean() * 100
# print(f"Logistic Regression Accuracy: {accuracy:.2f}%")

# # Visualize Logistic Regression
# plt.figure(figsize=(10, 6))
# plt.scatter(X_logistic, y, color='blue', label='Data Points')
# plt.scatter(X_logistic, y_pred_logistic, color='red', label='Predicted Probabilities')
# plt.xlabel('Length')
# plt.ylabel('Probability')
# plt.title('Logistic Regression: Length vs Probability of Age >= 10')
# plt.legend()
# plt.grid(True)
# plt.show()

# # Plot Log Loss over epochs
# plt.figure(figsize=(10, 6))
# plt.plot(range(len(mse_history_logistic)), mse_history_logistic, color='green')
# plt.xlabel('Epochs')
# plt.ylabel('Log Loss')
# plt.title('Log Loss vs Epochs (Logistic Regression)')
# plt.grid(True)
# plt.show()

# import pandas as pd
# import numpy as np
# import matplotlib.pyplot as plt

# # Load the dataset
# df = pd.read_csv("abalone.csv")

# # Define dependent variable (y)
# # Convert target to binary (1 if age >= 10, else 0)
# y = (df['Rings'] + 1.5 >= 10).astype(int)  # Age = Rings + 1.5

# # Define independent variables (X)
# X = df[['Length', 'Diameter', 'Height', 'Whole weight']].values  # Multiple features

# # Normalize the features
# X_mean = X.mean(axis=0)
# X_std = X.std(axis=0)
# X_normalized = (X - X_mean) / X_std

# # Add a bias term (column of 1's) to X
# X_normalized = np.c_[np.ones(X_normalized.shape[0]), X_normalized]

# # Sigmoid function
# def sigmoid(z):
#     return 1 / (1 + np.exp(-z))

# # Log loss (binary cross-entropy)
# def log_loss(y_true, y_pred):
#     return -np.mean(y_true * np.log(y_pred) + (1 - y_true) * np.log(1 - y_pred))

# # Gradient Descent for Logistic Regression
# def logistic_regression(X, y, learning_rate=0.01, epochs=1000):
#     """
#     Perform logistic regression with multiple features using gradient descent.
    
#     Parameters:
#     - X: Normalized feature matrix with bias term.
#     - y: True labels (binary).
#     - learning_rate: Learning rate for gradient descent.
#     - epochs: Number of iterations.
    
#     Returns:
#     - weights: Trained weights.
#     - loss_history: List of log loss values over epochs.
#     """
#     # Initialize weights
#     weights = np.zeros(X.shape[1])
#     n = len(X)
#     loss_history = []

#     for epoch in range(epochs):
#         # Forward pass
#         z = X @ weights
#         y_pred = sigmoid(z)

#         # Compute log loss
#         loss = log_loss(y, y_pred)
#         loss_history.append(loss)

#         # Backward pass (compute gradients)
#         error = y_pred - y
#         gradients = (X.T @ error) / n

#         # Update weights
#         weights -= learning_rate * gradients

#         # Print loss every 100 epochs
#         if epoch % 100 == 0:
#             print(f"Epoch {epoch}, Loss: {loss:.4f}")

#     return weights, loss_history

# # Train the model
# weights, loss_history = logistic_regression(X_normalized, y, learning_rate=0.01, epochs=1000)

# # Predict probabilities
# y_pred_prob = sigmoid(X_normalized @ weights)

# # Classify based on predicted probabilities
# y_pred_class = (y_pred_prob >= 0.5).astype(int)

# # Calculate Accuracy
# accuracy = (y == y_pred_class).mean() * 100
# print(f"Logistic Regression Accuracy: {accuracy:.2f}%")

# # Visualize the results (for one feature, e.g., Length)
# plt.figure(figsize=(10, 6))
# plt.scatter(X_normalized[:, 1], y, color='blue', label='Data Points')
# plt.scatter(X_normalized[:, 1], y_pred_prob, color='red', label='Predicted Probabilities')
# plt.xlabel('Length (Normalized)')
# plt.ylabel('Probability')
# plt.title('Logistic Regression: Length vs Probability of Age >= 10')
# plt.legend()
# plt.grid(True)
# plt.show()

# # Plot loss over epochs
# plt.figure(figsize=(10, 6))
# plt.plot(range(len(loss_history)), loss_history, color='green')
# plt.xlabel('Epochs')
# plt.ylabel('Log Loss')
# plt.title('Log Loss vs Epochs (Logistic Regression)')
# plt.grid(True)
# plt.show()

