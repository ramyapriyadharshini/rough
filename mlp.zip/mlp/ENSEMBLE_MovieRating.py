#!/usr/bin/env python
# coding: utf-8

# ----------------------------------------
# Import Libraries
# ----------------------------------------

import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

from sklearn.datasets import load_files
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split

from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import MultinomialNB
from sklearn.ensemble import VotingClassifier

from sklearn.metrics import classification_report, confusion_matrix, accuracy_score

# ----------------------------------------
# Load Dataset
# ----------------------------------------

path = r"C:\[0] college\2024 - 2025 Y3\[2] S6\Pattern Recog and ML\datasets"  # datasets dir must contain pos and neg dirs
dataset = load_files(path, encoding="latin-1", decode_error="replace")

df = pd.DataFrame({
    'message': dataset.data,
    'label': [dataset.target_names[i] for i in dataset.target]
})

# ----------------------------------------
# Dataset Exploration
# ----------------------------------------

print(df.head(100))
print(df.describe())
print(df.info())
print(df.isnull().sum())

# ----------------------------------------
# Preprocessing
# ----------------------------------------

X = df["message"]
y = df["label"]

# Encode target labels
conversion = {"neg": 0, "pos": 1}
y = y.map(conversion)

# Vectorize text data
vectorizer = TfidfVectorizer(stop_words="english")
X = vectorizer.fit_transform(X)

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# ----------------------------------------
# Model - Voting Classifier
# ----------------------------------------

ensemble = VotingClassifier(estimators=[
    ('lr', LogisticRegression(max_iter=1000)),
    ('nb', MultinomialNB()),
    ('dt', DecisionTreeClassifier())
], voting='hard')

ensemble.fit(X_train, y_train)

# ----------------------------------------
# Prediction and Evaluation
# ----------------------------------------

y_pred = ensemble.predict(X_test)

print(f"Model Accuracy: {accuracy_score(y_test, y_pred)}")
print(f"\nClassification Report:\n{classification_report(y_test, y_pred)}")

# ----------------------------------------
# Confusion Matrix
# ----------------------------------------

cm = confusion_matrix(y_test, y_pred)

sns.heatmap(cm, annot=True, cmap="Blues", fmt="d",
            xticklabels=["negative", "positive"],
            yticklabels=["negative", "positive"])
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.title("Confusion Matrix")
plt.show()
