#!/usr/bin/env python
# coding: utf-8

# ----------------------------
# Imports
# ----------------------------

import math
import random
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

# ----------------------------
# Load Dataset
# ----------------------------

df = pd.read_csv(r"C:\[0] college\2024 - 2025 Y3\[2] S6\Pattern Recog and ML\datasets\spam.csv", encoding="latin-1")
print(df.head())
print(df.isnull().sum())

# ----------------------------
# Preprocessing
# ----------------------------

# Feature selection
df = df[["v1", "v2"]]

# Rename columns
df.columns = ["label", "message"]

# Label conversion
conversion = {"ham": 0, "spam": 1}
df["label"] = df["label"].map(conversion)

# ----------------------------
# Feature Extraction
# ----------------------------

vectorizer = CountVectorizer(stop_words="english")
X = vectorizer.fit_transform(df["message"]).toarray()
y = df["label"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# ----------------------------
# Model Training
# ----------------------------

model = MultinomialNB()
model.fit(X_train, y_train)

# ----------------------------
# Prediction and Evaluation
# ----------------------------

y_pred = model.predict(X_test)

print("Accuracy:", accuracy_score(y_test, y_pred))
print("\nClassification Report:\n", classification_report(y_test, y_pred))
print("\nConfusion Matrix:\n", confusion_matrix(y_test, y_pred))

# ----------------------------
# Confusion Matrix Plot
# ----------------------------

cm = confusion_matrix(y_test, y_pred)

plt.figure(figsize=(5, 4))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=['Ham', 'Spam'], yticklabels=['Ham', 'Spam'])
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.title('Confusion Matrix')
plt.show()

# Notes:
# - GaussianNB → Use for numerical data
# - MultinomialNB → Best for text classification
