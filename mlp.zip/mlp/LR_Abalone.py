#!/usr/bin/env python
# coding: utf-8

# ----------------------------
# Library import
# ----------------------------

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

# ----------------------------
# Load dataset
# ----------------------------

df = pd.read_csv(r"C:\[0] college\2024 - 2025 Y3\[2] S6\Pattern Recog and ML\datasets\abalone.csv")

# ----------------------------
# Exploration
# ----------------------------

print(df.head())
print(df.describe())
print(df.info())
print(df.isnull().sum())

plt.figure(figsize=(10, 6))
sns.heatmap(df.select_dtypes(include=["number"]).corr(), annot=True, cmap="coolwarm")
plt.show()

# ----------------------------
# Preprocessing
# ----------------------------

df["Age"] = df["Rings"] + 1.5
X = df[["Diameter"]].values
y = df["Age"].values

scaler = StandardScaler()
X = scaler.fit_transform(X)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# ----------------------------
# Model
# ----------------------------

model = LinearRegression()
model.fit(X_train, y_train)

y_pred = model.predict(X_test)

mse = mean_squared_error(y_test, y_pred)
mae = mean_absolute_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print(f"Mean Squared Error (MSE): {mse:.2f}")
print(f"Mean Absolute Error (MAE): {mae:.2f}")
print(f"R² Score: {r2:.2f}")

plt.figure(figsize=(10, 6))
plt.scatter(X_test, y_test, color='blue', label="Actual Age")
plt.plot(X_test, y_pred, color='red', label="Predicted Age")
plt.xlabel("Standardized Diameter")
plt.ylabel("Age")
plt.title("Linear Regression: Diameter vs Age")
plt.legend()
plt.grid(True)
plt.show()
