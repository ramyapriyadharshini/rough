#!/usr/bin/env python
# coding: utf-8

# ----------------------------------------
# Import Libraries
# ----------------------------------------

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import re
import seaborn as sb
import os

from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

import nltk
from nltk.corpus import stopwords

# ----------------------------------------
# Load Data from Text Files
# ----------------------------------------

data_dir = "D:/Clg/sem 6/ML/end_sem/naruto-1-5/Movie review/aclImdb/train"
data = []

for label in ["pos", "neg"]:
    folder_path = os.path.join(data_dir, label)
    for filename in os.listdir(folder_path):
        file_path = os.path.join(folder_path, filename)
        if os.path.isfile(file_path) and filename.endswith(".txt"):
            with open(file_path, "r", encoding="utf-8", errors="ignore") as file:
                content = file.read()
                data.append((content, label))

df = pd.DataFrame(data, columns=["text", "label"])
df.to_csv("movie_review.csv", index=False)

# ----------------------------------------
# Download NLTK Stopwords
# ----------------------------------------

nltk.download("stopwords")

# ----------------------------------------
# Read and Preprocess Data
# ----------------------------------------

df = pd.read_csv("movie_review.csv")
df["label"] = df["label"].map({"pos": 1, "neg": 0})

# Check for nulls
print(df.head(5))
print("Missing Labels:", df["label"].isnull().sum())

# ----------------------------------------
# Text Preprocessing Function
# ----------------------------------------

stop_words = set(stopwords.words("english"))

def preprocess_text(text):
    text = text.lower()
    text = re.sub(r"\<.*?\>", "", text)
    text = re.sub(r"https?://\S+|www\.\S+", "", text)
    text = re.sub(r"[^a-zA-Z]", " ", text)
    words = text.split()
    words = [word for word in words if word not in stop_words]
    return " ".join(words)

df["text"] = df["text"].apply(preprocess_text)

# ----------------------------------------
# Train-Test Split
# ----------------------------------------

x_train, x_test, y_train, y_test = train_test_split(df["text"], df["label"], test_size=0.2, random_state=42)

# TF-IDF Vectorization
vectorizer = TfidfVectorizer()
x_train = vectorizer.fit_transform(x_train)
x_test = vectorizer.transform(x_test)

# ----------------------------------------
# Decision Tree Classifier
# ----------------------------------------

dt_model = DecisionTreeClassifier(max_depth=10, random_state=42)
dt_model.fit(x_train, y_train)
dt_pred = dt_model.predict(x_test)

print("\n--- Decision Tree Classifier ---")
print("Accuracy:", accuracy_score(y_test, dt_pred))
print("Classification Report:\n", classification_report(y_test, dt_pred))
print("Confusion Matrix:\n", confusion_matrix(y_test, dt_pred))

# ----------------------------------------
# Random Forest Classifier
# ----------------------------------------

rf_model = RandomForestClassifier(max_depth=10, random_state=42)
rf_model.fit(x_train, y_train)
rf_pred = rf_model.predict(x_test)

print("\n--- Random Forest Classifier ---")
print("Accuracy:", accuracy_score(y_test, rf_pred))
print("Classification Report:\n", classification_report(y_test, rf_pred))
print("Confusion Matrix:\n", confusion_matrix(y_test, rf_pred))
