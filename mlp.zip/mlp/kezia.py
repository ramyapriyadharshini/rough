import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

from sklearn.datasets import load_files # to open file
from sklearn.feature_extraction.text import TfidfVectorizer # vectorizer for text preprocessing
from sklearn.model_selection import train_test_split # data splitting 
from sklearn.tree import DecisionTreeClassifier # model for text classification 
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score

path = r"C:\\[0] college\\2024 - 2025 Y3\\[2] S6\\Pattern Recog and ML\\datasets" # datasets dir must contain pos and neg dirs 
dataset = load_files(path, encoding="latin-1", decode_error="replace")

df = pd.DataFrame({
    'message': dataset.data,
    'label': [dataset.target_names[i] for i in dataset.target]
})

df.head(100)
df.describe()
df.info()
df.isnull().sum()

X = df["message"]
y = df["label"]

# encode y
conversion = {"neg":0, "pos":1}
y = y.map(conversion)

# vectorize X (converts texts to numbers) and convert to array
vectorizer = TfidfVectorizer(stop_words="english")
X = vectorizer.fit_transform(X)

# split 
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model_1 = DecisionTreeClassifier(criterion="gini", max_depth=10, random_state=42)
model_2 = RandomForestClassifier(n_estimators=50, max_depth=20, random_state=42)

model_1.fit(X_train, y_train) # training
model_2.fit(X_train, y_train) # training

y_pred_1 = model_1.predict(X_test)
y_pred_2 = model_2.predict(X_test)

print(f"Decision Tree Model Accuracy: {accuracy_score(y_pred_1, y_test)}")
print(f"\nClassification Report: \n{classification_report(y_test, y_pred_1)}")
print()
print(f"Random Forest Model Accuracy: {accuracy_score(y_pred_2, y_test)}")
print(f"\nClassification Report: \n{classification_report(y_test, y_pred_2)}")

cm1 = confusion_matrix(y_test, y_pred_1)

sns.heatmap(cm1, annot=True, cmap="Blues", fmt="d", xticklabels=["negative", "positive"], yticklabels=["neutral", "positive"])
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.title("Confusion Matrix")
plt.show()

cm2 = confusion_matrix(y_test, y_pred_2)

sns.heatmap(cm2, annot=True, cmap="Blues", fmt="d", xticklabels=["neutral", "positive"], yticklabels=["neutral", "positive"])
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.title("Confusion Matrix")
plt.show()
